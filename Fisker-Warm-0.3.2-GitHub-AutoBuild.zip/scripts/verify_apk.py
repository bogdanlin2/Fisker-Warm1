#!/usr/bin/env python3
"""Inspect the built APK's signature and finite foreground-only manifest contract."""
import argparse
import hashlib
import json
import re
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def run(argv):
    return subprocess.run([str(a) for a in argv], check=True, text=True, capture_output=True).stdout

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--build-tools', required=True)
    parser.add_argument('--apk', default=str(ROOT/'dist/Fisker-Warm-Lab-0.3.2.apk'))
    args = parser.parse_args()
    bt = Path(args.build_tools).resolve()
    apk = Path(args.apk).resolve()
    java = shutil.which('java')
    if not java: parser.error('JDK required')
    signature = run([java,'-jar',bt/'lib/apksigner.jar','verify','--verbose','--print-certs',apk])
    xml = run([bt/'aapt2','dump','xmltree','--file','AndroidManifest.xml',apk])
    run([bt/'zipalign','-c','4',apk])
    permissions = set(re.findall(r'"(android\.permission\.[A-Z_]+)"', xml))
    expected = {'android.permission.BLUETOOTH','android.permission.BLUETOOTH_ADMIN',
                'android.permission.ACCESS_FINE_LOCATION','android.permission.BLUETOOTH_SCAN',
                'android.permission.BLUETOOTH_CONNECT'}
    checks = {
        'apkSignatureV2': 'Verified using v2 scheme (APK Signature Scheme v2): true' in signature,
        'apkSignatureV3': 'Verified using v3 scheme (APK Signature Scheme v3): true' in signature,
        'exactPermissionSet': permissions == expected,
        'noInternet': 'android.permission.INTERNET' not in permissions,
        'noServicesReceiversProviders': not re.search(r'E: (service|receiver|provider)\b',xml),
        'onlyOneActivity': len(re.findall(r'E: activity\b',xml)) == 1,
        'notDebuggable': bool(re.search(r':debuggable\([^\n]+\)=false',xml)),
        'backupDisabled': bool(re.search(r':allowBackup\([^\n]+\)=false',xml)),
        'cleartextDisabled': bool(re.search(r':usesCleartextTraffic\([^\n]+\)=false',xml)),
        'aligned': True,
    }
    result = {'apk':apk.name,'sha256':hashlib.sha256(apk.read_bytes()).hexdigest(),
              'checks':checks,'installedOnPhone':False,'vehicleTested':False,
              'scope':'Artifact inspection only; does not validate BLE hardware or heating.'}
    out = ROOT/'build'; out.mkdir(exist_ok=True)
    (out/'apk-manifest-tree.txt').write_text(xml,encoding='utf-8')
    (out/'apk-inspection.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))
    if not all(checks.values()): raise SystemExit('APK contract inspection failed')

if __name__ == '__main__': main()
